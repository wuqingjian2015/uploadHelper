from flask import Flask, render_template, request
import pickle
import shutil
import time
import os
from datetime import datetime


app = Flask(__name__)
author = 'Wu Qingjian'
email = 'wuqingjian2014@icloud.com'


@app.route("/")
def welcome():
    return '<h1>welcome<a href="/ArchFlow">ArchFlow</a></h1>'


@app.route("/ArchFlow")
def listAll():
     return render_template("requirementIndex.html")

@app.route("/ArchFlow/upload", methods=['post'])
def uploadFile():
    context = dict()
    for p in request.files:
        context[p] = request.files[p]
        # print(request.files['toUploadFile'])
        context['uploadFile'].save('data//'+context['uploadFile'].filename)

    return 'upload file'

if __name__ == "__main__":
    app.run('',8080)

